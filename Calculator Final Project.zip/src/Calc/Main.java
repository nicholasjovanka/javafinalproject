package Calc;
import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Main { //The main
    public static void main(String[] args){
        try {
            Calculator gui = new Calculator(); //To create the gui object
            CalculatorFunction obj= new CalculatorFunction();
            System.out.println(obj.infixtopostfix("(10*5+3)-10"));
            gui.setExtendedState(JFrame.MAXIMIZED_BOTH);    //To make sure that the gui doesnt start minimized
            gui.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) { //To end the program when the gui is closed
                    System.out.println("Closing Program");
                    System.exit(0);
                }
            });
            gui.setVisible(true);

        }
        catch (Exception e){
            throw e;
        }

    }
}
