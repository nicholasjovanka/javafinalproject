package Calc;


import java.util.Scanner;
import java.io.*;
import java.util.HashMap;
import java.util.*;


interface calculatorinterface{                         //Interface that implements the hashmap and function tot he CalculatorFunction Class
    HashMap<Character,Double> map= new HashMap<Character, Double>();
    boolean isProgrammable(char a);
    boolean isOperand(char a);
    boolean isOperator(char a);
    int weight(char a);
    boolean isHigher(char a,char b);
    boolean ishigher(char a,char b);
    double calculate(char operate,double a,double b);
    String infixtopostfix(String a);
    String evaluate(String a);
}

public class CalculatorFunction implements calculatorinterface { //The class that contains all the functions
    public boolean isProgrammable(char a){ //This boolean checks whether a char is either 'x' or 'y'
        if(a=='x'||a=='y'){
            return true;
        }
        else{
            return false;
        }
    }
    public boolean isOperand(char a){  //This boolean check whether a char is an operand or not
        if(a=='1'||a=='2'||a=='3'||a=='4'||a=='5'||a=='6'||a=='7'||a=='8'||a=='9'||a=='0'){
            return true;
        }
        else{
            return false;
        }
    }
    public boolean isOperator(char a){ //This boolean check whether a char is an operator or not
        if(a=='+'||a=='-'||a=='*'||a=='/'||a=='^')
        {
            return true;
        }
        else{
            return false;
        }
    }
    public int weight(char a){ //This int function return the weight of an operator where if the operator has higher Precedence it will have a bigger weight
        int charweight=0;
        if(a=='^'){
            charweight=3;
        }
        else if(a=='*'||a=='/'){
            charweight=2;
        }
        else if(a=='+'||a=='-'){
            charweight=1;
        }
        return charweight;
    }
    public boolean isHigher(char a,char b){ //This int function check whether an operator have bigger precedence then the other operator
        if(weight(a)>weight(b)){
            return true;
        }
        else{
            return false;
        }
    }
    public boolean ishigher(char a,char b) {//This int function check whether an operator have bigger or equal precedence then the other operator
        if (weight(a) >= weight(b)) {
            return true;
        } else {
            return false;
        }
    }

    public String infixtopostfix(String infixexpression){ //This function converts infixexpressioninto postfix
        char[] infix=infixexpression.toCharArray(); //Convert the string infixexpression into a char array so that it could be iterated using index
        String postfix=""; //The String holds the result of the conversion
        int isdouble=0; //counter whether a number is double
        int isdecimal=0;// coutner whether a number is a decimal
        Stack<Character> stack= new Stack<Character>(); //This stack is used to store the operator
        for(int i=0;i<infix.length;i++) {
            if(isProgrammable(infix[i])){ //check whether the char i is a 'x' or 'y'
                if(infix.length==1){ //check if only x or y is inputted in the whole expression
                    postfix+=infix[i];
                    continue;
                }
                else if(i==0&&infix[i+1]=='='){ //Check if the user is trying to assign a value to the key 'x' or 'y'
                    int start=i+1+1; //Get the starting index of the value that the user want bind to the key
                    int end=infix.length-1; //get the the last index of the value that the user want to bind to the key
                    String number=""; //String placeholder to store the value that the user want to bind
                    for(int b=start;b<=end;b++){ //append all the char from the start to the end index
                        number+=infix[b];
                    }
                    String insertnumber=evaluate(infixtopostfix(number)); //Incase the user inputted an equation
                    Double num=Double.parseDouble(insertnumber); //convert the string insertnumber to double
                    Character key=infix[0]; //get the key
                    map.put(key, num); //set the key and the value

                }
                else{
                    postfix+=infix[i]; //Else it just pushes the char to the postfix string
                }

            }
            if (infix[i] == '(') { //Push the symbol to the stack
                stack.push('(');
            }
            else if(infix[i]=='.'){ //if the car is . that detect a decimal
                postfix+=infix[i];
                isdecimal++; //add the decimal counter
            }
            else if (isOperand(infix[i])) { //Detect if char is operand
                if(i==0){ //check specifically at the first index
                    if(infix.length>1&&isOperand(infix[i+1])){ //Check if its a double
                        postfix += '[';
                        postfix += infix[i];
                        isdouble++; //add the decimal counter
                    }
                    else{
                        postfix+=infix[i]; //else just add the char to the postfix
                    }
                }
                else if(i==infix.length-1){ //check specifically at the last index
                    if(isdouble==1){ //If the double counter is on it will add ']'
                        postfix += infix[i];
                        postfix += ']';
                        isdouble--; //turn off the double counter
                    }
                    else if(isdecimal==1){ //Check if the decimal counter is on where if its on it will add the ',' synbol to the end to detect if its a decimal
                        postfix+=infix[i];
                        postfix+=',';
                        isdecimal--; //Turn off the decimal counter
                    }
                    else{
                        postfix+=infix[i]; //if none of the above just append to the postfix string
                    }
                }
                else{
                    if((isOperand(infix[i + 1]) && isOperator(infix[i - 1]))||(infix[i - 1] == '(' && isOperand(infix[i + 1]))){ //Check whether a number is the start of the double
                        if(isdouble==0) {
                            postfix += '['; //Add the symbol'[' to mark if a number is double
                            postfix += infix[i];
                            isdouble++; //Turn on the isdouble counter
                        }
                        else{
                            continue;
                        }
                    }
                    else if((isOperator(infix[i+1])&&isdouble==1)||(isdouble==1&&infix[i+1]==')')){ //Check if the char is the end of a double
                        postfix += infix[i];
                        postfix += ']'; //Add the ']' to the end of the number to show that its a double
                        isdouble--;
                        if(isdecimal==1){ //To turn off the isdecimal counter incase it got turned on inside a double
                            isdecimal--;
                        }
                    }
                    else if((isOperator(infix[i+1])&&isdecimal==1)||(isdecimal==1&&infix[i+1]==')')){ //If the decimal counter is on it will add ',' to the end of the decimal number to sign that it is a decimal
                        postfix+=infix[i];
                        postfix+=',';
                        isdecimal--; //Turn off the decimal diagram
                    }
                    else{
                        postfix+=infix[i];
                    }
                }
            }
            else if (infix[i] == ')') {
                while (stack.peek() != '(') { //Pop all the operator and append it to the postfix string until the '(' is found.
                    char oper = stack.pop();
                    postfix += oper;
                }
                if (stack.peek() == '(') {
                    stack.pop(); //remove '(' from the stack
                }
            } else if (isOperator(infix[i])) { //Check if the current character is an operator
                if (infix[i] == '-') {  //check specifically whether the operator is -
                    if (i == 0) { //The - is for negative number so the - is replaced with ' " "
                        postfix += '"';
                    } else {
                        if ((infix[i] == '-' && isOperator(infix[i - 1])) || (infix[i] == '-' && infix[i - 1] == '(')) { //Check whether a minus is for negative number replace the minus with" ' "
                            postfix += '"';
                        }
                        else if (stack.empty() || stack.peek() == '(') { //else just push the - as an operator
                            stack.push(infix[i]);
                        } else if (isHigher(infix[i], stack.peek())) { //Check whether the operator in the top of the stack is lower then the - where if the - is higher it will push it to the stack
                            stack.push(infix[i]);
                        }
                        else {
                            while (!stack.empty()&&ishigher(stack.peek(), infix[i])) { //If the current operator in the stack is higher then pop-
                                char operator = stack.pop();                           //-all operator in the stack that is higher or equal in the weight then the -  then append them to the postfix string and push the minus to the stack
                                postfix += operator;
                            }
                            stack.push(infix[i]);
                        }
                    }
                } else {
                    if (stack.empty() || stack.peek() == '(') { //If the stack is empty or the top is')' just push the operator to teh stack
                        stack.push(infix[i]);
                    } else if (isHigher(infix[i], stack.peek())) {//Check whether the operator in the top of the stack is lower then the current operator where if the - is higher it will push it to the stack
                        stack.push(infix[i]);
                    } else {
                        if(!stack.empty()) {
                            while (!stack.empty()&&ishigher(stack.peek(), infix[i])) {//If the operator in the stack is higher then the current operator then pop out and append the operator to the postfix string that is higher and equal to the operator
                                char operator = stack.pop();
                                postfix += operator;
                            }
                        }
                        stack.push(infix[i]); //append the operator to the stack
                    }
                }

            }
        }
        while(stack.empty()!=true){ //after the iteration is complete pop and append all the operator in the stack to the postfix
            char b=stack.pop();
            postfix+=b;
        }
        return postfix;
    }
        public double calculate(char operator,double a,double b){ //This function is used in the evaluate to execute the operation.
        if(operator=='+'){
            double value=a+b;
            return value;
        }
        else if(operator=='-'){
            double value=a-b;
            return value;
        }
        else if(operator=='*'){
            double value=a*b;
            return value;
        }
        else if(operator=='/'){
            double value=a/b;
            return value;
        }
        else if(operator=='^'){
            double value=1;
            for(int i=0;i<b;i++){
                value=value*a;
            }
            return value;
        }
        else{
            return 0;
        }
    }
    public String evaluate(String a){ //Evaluate the postfix expression to get the numerical result
        int isminus=0; //Counter as a switch to check if a negative number is detected
        int start=0; //To store the index of the start of the double number
        int startdecimal=0; //to store the index of the start of a decimal number
        int enddecimal=0; //to store the index of the last of a double number
        int end=0; //to store the index of the last index of the double number
        int isdoubledigit=0; //Counter as a switch to check if a double number is detected
        int isdecimal=0; //Counter as a switch to check if a decimal number is detected
        Stack<Double> stack=new Stack<Double>(); //stack to push the double
        String result; //String to hold the end result
        char[] postfix=a.toCharArray(); //To convert string to a char array to iterate
        for(int i=0;i<postfix.length;i++){
            if(isProgrammable(postfix[i])){ //if its a programmable button then it will get the value from the hashmap
                if(isminus==1){ ///if its minus it will push the value as minus
                    stack.push(-(map.get(postfix[i])));
                    isminus--; //turn off the counter
                }
                else {
                    stack.push(map.get(postfix[i]));
                }
            }
            else if(postfix[i]=='"'){ //if a ' " ' the is minus is on
                isminus++;
            }
            else if(postfix[i]=='['){ //if a ' [ ' i turn on the double digit counter
                isdoubledigit++;
                start=i+1; //get the index of the start of the double number
            }
            else if(isOperand(postfix[i])){ //if the character is an operand
                if(postfix.length>1&&postfix[i+1]==']'){ //if a ']' char is found then it will append the number as double
                    String number=""; //string to hold the double number
                    end=i; //index of the last number of the double number
                    isdoubledigit--; //turn off the doubledigit switch
                    for(int b=start;b<=end;b++){
                        number+=postfix[b]; //append all the number char from the index start to the index end to the string
                    }
                    Double num=Double.parseDouble(number); //Parse the string into a double
                    if(isminus>0){ //if the ismminus counter is on then it will push the double as negative number
                        isminus--;
                        stack.push(-num);
                    }
                    else{ //Else it just push the double
                        stack.push(num);
                    }
                }
                else if(postfix.length>1&&postfix[i+1]==','){ //if the character ',' is found then will push the number as decimal
                    enddecimal=i; //get the last index of the decimal
                    String number=""; //string to hold the decimal number
                    isdecimal--; //turn off the decimal counter
                    for(int z=startdecimal;z<=enddecimal;z++){
                        number+=postfix[z];//append all the number char form the index startdecimal to the index enddecimal
                    }
                    Double num= Double.parseDouble(number); //parse the string into a double
                    if(isminus>0){//if the ismminus counter is on then it will push the decimal as negative number
                        isminus--;
                        stack.push(-num);
                    }
                    else{
                        stack.push(num);//Else it just push the decimal mumber to the stack
                    }
                }
                else if(isdoubledigit==1||isdecimal==1){ //If the isdoubledigit or the isdecimal counter is on just continue to the next iteration
                    continue;
                }
                else if(postfix.length>1&&postfix[i+1]=='.'){ //if a ' . ' is found just turn on the isdecimal counter
                    isdecimal++;
                    startdecimal=i;
                }

                else if(isminus>0){ //if the is minus is on just push the number as negative number to the stack
                    double num=(double)(postfix[i]-'0');
                    stack.push(-num);
                    isminus--;
                }
                else{
                    double num=(double)(postfix[i]-'0'); //Just push to the stack
                    stack.push(num);
                }
            }
            else if(isOperator(postfix[i])){  //if an operator is found then it will pop 2 number form the stack and then calculate the 2 number with the operator
                double num1=stack.pop();
                double num2=stack.pop();
                double calc=calculate(postfix[i],num2,num1);
                stack.push(calc); //push the number
            }
        }
        result=String.valueOf(stack.pop()); //Get the end result
        return result; //return the result
    }

}


