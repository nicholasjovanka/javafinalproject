package Calc;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class Calculator extends JFrame {
    CalculatorFunction guiobject=new CalculatorFunction(); //call the calculatorfuntion object so the function can be called
    public static String equation=""; //String that is shown in the jtextfield
    private JPanel RootPanel; //the root panel of the gui
    private JButton button1;
    private JButton a8Button;
    private JTextField textField1;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton a9Button;
    private JButton button7;
    private JButton xButton;
    private JButton button8;
    private JButton button9;
    private JButton a4Button;
    private JButton a5Button;
    private JButton a6Button;
    private JButton a1Button;
    private JButton a2Button;
    private JButton a3Button;
    private JButton a0Button;
    private JButton button16;
    private JButton button2;
    private JButton cButton;
    private JButton xButton2;
    private JButton yButton;
    private JButton button6;
    private JTextField toProgramTheXTextField;

    public Calculator() { //constructor for the calculator gui
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); //Windows Look and feel //Change the style of the gui form
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
        add(RootPanel);
        a1Button.addActionListener(new ActionListener() { //if the button is pressed add the char 1 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="1";
                textField1.setText(equation);
            }
        });
        a2Button.addActionListener(new ActionListener() {//if the button is pressed add the char 2 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="2";
                textField1.setText(equation);
            }
        });
        a0Button.addActionListener(new ActionListener() {//if the button is pressed add the char 0 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="0";
                textField1.setText(equation);
            }
        });
        a3Button.addActionListener(new ActionListener() {//if the button is pressed add the char 3 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="3";
                textField1.setText(equation);
            }
        });
        button9.addActionListener(new ActionListener() {//if the button is pressed add the char ^ to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="^";
                textField1.setText(equation);
            }
        });
        a4Button.addActionListener(new ActionListener() {//if the button is pressed add the char 4 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="4";
                textField1.setText(equation);
            }
        });
        a5Button.addActionListener(new ActionListener() {//if the button is pressed add the char 5 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="5";
                textField1.setText(equation);
            }
        });
        a6Button.addActionListener(new ActionListener() {//if the button is pressed add the char 6 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="6";
                textField1.setText(equation);
            }
        });
        button8.addActionListener(new ActionListener() {//if the button is pressed add the char / to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="/";
                textField1.setText(equation);
            }
        });
        button1.addActionListener(new ActionListener() {//if the button is pressed add the char 7 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="7";
                textField1.setText(equation);
            }
        });
        a8Button.addActionListener(new ActionListener() {//if the button is pressed add the char 8 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="8";
                textField1.setText(equation);
            }
        });
        a9Button.addActionListener(new ActionListener() {//if the button is pressed add the char 9 to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="9";
                textField1.setText(equation);
            }
        });
        xButton.addActionListener(new ActionListener() {//if the button is pressed add the char * to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="*";
                textField1.setText(equation);
            }
        });
        button3.addActionListener(new ActionListener() {//if the button is pressed add the char ( to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="(";
                textField1.setText(equation);
            }
        });
        button4.addActionListener(new ActionListener() {//if the button is pressed add the char ) to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+=")";
                textField1.setText(equation);
            }
        });
        button5.addActionListener(new ActionListener() {//if the button is pressed add the char + to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="+";
                textField1.setText(equation);
            }
        });
        button7.addActionListener(new ActionListener() {//if the button is pressed add the char - to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="-";
                textField1.setText(equation);
            }
        });
        button16.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                char[] check=equation.toCharArray();
                if((check[0]=='x'||check[0]=='y')&&check.length==1){ //check if the user only input x or y
                    equation = guiobject.evaluate(guiobject.infixtopostfix(equation));
                    textField1.setText(equation);
                }
                else if(check[0]=='x'&&check[1]=='='||check[0]=='y'&&check[1]=='='){//check if the user want to program a value
                    guiobject.infixtopostfix(equation);
                    equation="";
                    textField1.setText(equation);
                }
                else {
                    equation = guiobject.evaluate(guiobject.infixtopostfix(equation));//if the user input an arithmatical expression
                    textField1.setText(equation);
                }
            }
        });
        cButton.addActionListener(new ActionListener() { //the c button that clear the string displayed
            @Override
            public void actionPerformed(ActionEvent e) {
                equation="";
                textField1.setText(equation);
            }
        });
        button2.addActionListener(new ActionListener() {//if the button is pressed add the char . to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+=".";
                textField1.setText(equation);
            }
        });
        xButton2.addActionListener(new ActionListener() {//if the button is pressed add the char x to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="x";
                textField1.setText(equation);
            }
        });
        yButton.addActionListener(new ActionListener() {//if the button is pressed add the char y to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="y";
                textField1.setText(equation);
            }
        });
        button6.addActionListener(new ActionListener() {//if the button is pressed add the char = to the equation string
            @Override
            public void actionPerformed(ActionEvent e) {
                equation+="=";
                textField1.setText(equation);
            }
        });
    }
}
